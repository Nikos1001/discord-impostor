

class User:

    def __init__(self, id, agent):
        self.id = id
        self.agent = agent
        self.username = ''